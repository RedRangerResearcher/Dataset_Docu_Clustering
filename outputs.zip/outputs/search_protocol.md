# MANU PATRA SEARCH PROTOCOL FOR Multi-View Representation-Based Clustering of Judicial Documents

## Dataset Creation Date
[10 December 2024]

## Search Parameters

### 1. Database
- **Platform**: Manupatra Fast
- **Module**: Case Law Search
- **Access**: [Personal/Institutional] subscription

### 2. Search Criteria
- **Search Query**: [Describe your exact search terms, e.g., "Section 482 AND CrPC AND quashing"]
- **Date Range**: [e.g., 01 January 2000 to 31 December 2022]
- **Court Selection**: [e.g., Supreme Court of India, All High Courts]
- **Judgment Type**: [e.g., Reported judgments only]
- **Bench Strength**: [e.g., Division Bench and above]

### 3. Search Execution
1. Logged into Manupatra Fast platform
2. Navigated to Advanced Case Law Search
3. Applied the above filters
4. Executed search on [Date]
5. Initial results: [Number] cases

### 4. Dataset Refinement
- Manual screening for relevance: Yes/No
- Exclusion criteria: [Describe any cases excluded]
- Final corpus: [Number] cases

### 5. Data Extraction
- Format: Full text in .txt format
- Extraction method: Manual download via "Save as text" option
- File naming convention: MANU_[Court]_[Number]_[Year].txt

## Notes
- This dataset was created for academic research purposes only
- Full texts remain copyright of respective courts and Manupatra
- Only metadata and derived analyses are shared publicly

## How to Reconstruct
To reconstruct this exact dataset:
1. Access Manupatra Fast with valid credentials
2. Apply the search criteria listed above
3. The results should match the cases listed in `case_metadata.csv`
